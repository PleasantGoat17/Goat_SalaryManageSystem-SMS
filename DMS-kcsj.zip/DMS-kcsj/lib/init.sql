-- Employee (员工表)
INSERT INTO Employee (EmployeeID, Name, TiTleID, PositionID, DepartmentID, HireDate, BasicSalary)VALUES
(0001, '张三', 0001, 0001, 0001,'2022-01-10', 5000.0),
